package com.malykbrown.musicwallpaper

import android.graphics.Bitmap
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class TrackInfo(
    val title: String = "",
    val artist: String = "",
    val art: Bitmap? = null,
    val artKey: String = ""
)

data class HistoryItem(val title: String, val artist: String, val time: String)

object NowPlaying {
    private val _state = MutableStateFlow(TrackInfo())
    val state: StateFlow<TrackInfo> = _state

    private val _history = MutableStateFlow<List<HistoryItem>>(emptyList())
    val history: StateFlow<List<HistoryItem>> = _history

    private val timeFmt = SimpleDateFormat("HH:mm", Locale.getDefault())

    fun update(title: String, artist: String, art: Bitmap?) {
        val key = "$title|$artist|${art?.width}x${art?.height}"
        if (key == _state.value.artKey) return
        _state.value = TrackInfo(title, artist, art, key)
        if (title.isNotEmpty()) {
            val item = HistoryItem(title, artist, timeFmt.format(Date()))
            _history.value = (listOf(item) + _history.value).take(15)
        }
    }
}
