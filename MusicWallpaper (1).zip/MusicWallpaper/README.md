# Music Wallpaper — Liquid Glass (Malyk Brown 2026)

Live wallpaper Android que muda com a musica, com interface em vidro liquido
(Jetpack Compose + RenderEffect + AGSL shader).

## Funcionalidades
- Live wallpaper que troca a arte do album com crossfade
- Leitor com barra de progresso arrastavel e controlos em glifo
- Dock com bezel de vidro que desliza para o separador tocado
- Equalizador (Android Equalizer), Perfil e Historico
- Alternar entre vidro Transparente e Tingido

## Requisitos
- minSdk 33 (o shader AGSL de refracao precisa de Android 13+)

## Compilar no GitHub (Codespaces)
Abre o Codespaces no teu repo, arrasta o `MusicWallpaper.zip` e corre:

```bash
unzip -o "MusicWallpaper.zip"
cp -r MusicWallpaper/* .
cp -r MusicWallpaper/.github .
rm -rf MusicWallpaper "MusicWallpaper.zip"
git add -A
git commit -m "Music Wallpaper 2.0 - liquid glass UI"
git push
```

Depois: **Actions -> Build APK -> MusicWallpaper-debug** para descarregar o APK.

## Configurar no telemovel
1. Instala o APK
2. App -> "Activar acesso as notificacoes" -> liga o Music Wallpaper Listener
3. "Definir como papel de parede" -> Aplicar
4. Toca uma musica (Spotify/YT Music) — a arte aparece no wallpaper

## Nota tecnica sobre o vidro
O efeito de desfoque e o brilho/reflexo do vidro funcionam em toda a interface.
A *refracao que distorce o fundo* (estilo iOS) usa um shader AGSL aplicado a camada;
no Android, amostrar o conteudo ESTRITAMENTE por tras de uma view (como o
`backdrop-filter` do CSS) tem limitacoes. Esta versao aplica o shader + desfoque por
camada — o visual de vidro/reflexo fica fiel; se quiseres a refracao a distorcer o
wallpaper por tras em tempo real, o proximo passo e renderizar o fundo para um
RenderNode partilhado e amostra-lo no shader. Posso adicionar isso a seguir.
