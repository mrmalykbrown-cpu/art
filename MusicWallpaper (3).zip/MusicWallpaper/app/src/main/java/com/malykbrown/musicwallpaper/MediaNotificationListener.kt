package com.malykbrown.musicwallpaper

import android.content.ComponentName
import android.graphics.Bitmap
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.service.notification.NotificationListenerService

class MediaNotificationListener : NotificationListenerService() {

    private var sessionManager: MediaSessionManager? = null
    private var activeController: MediaController? = null

    private val controllerCallback = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) { push() }
        override fun onPlaybackStateChanged(state: PlaybackState?) { refreshSessions() }
    }

    private val sessionsListener =
        MediaSessionManager.OnActiveSessionsChangedListener { refreshSessions() }

    override fun onListenerConnected() {
        super.onListenerConnected()
        sessionManager = getSystemService(MediaSessionManager::class.java)
        val component = ComponentName(this, MediaNotificationListener::class.java)
        try {
            sessionManager?.addOnActiveSessionsChangedListener(sessionsListener, component)
        } catch (_: SecurityException) {}
        refreshSessions()
    }

    override fun onListenerDisconnected() {
        sessionManager?.removeOnActiveSessionsChangedListener(sessionsListener)
        detach()
        super.onListenerDisconnected()
    }

    private fun refreshSessions() {
        val component = ComponentName(this, MediaNotificationListener::class.java)
        val sessions = try {
            sessionManager?.getActiveSessions(component) ?: emptyList()
        } catch (_: SecurityException) { emptyList() }
        val playing = sessions.firstOrNull {
            it.playbackState?.state == PlaybackState.STATE_PLAYING
        } ?: sessions.firstOrNull()

        if (playing?.sessionToken != activeController?.sessionToken) {
            detach()
            activeController = playing?.also { it.registerCallback(controllerCallback) }
            NowPlaying.transport = activeController?.transportControls
        }
        push()
    }

    private fun detach() {
        activeController?.unregisterCallback(controllerCallback)
        activeController = null
        NowPlaying.transport = null
    }

    private fun push() {
        val c = activeController
        val metadata = c?.metadata
        val isPlaying = c?.playbackState?.state == PlaybackState.STATE_PLAYING
        if (metadata == null) return
        val title = metadata.getString(MediaMetadata.METADATA_KEY_TITLE) ?: ""
        val artist = metadata.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: metadata.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST) ?: ""
        val art: Bitmap? = metadata.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: metadata.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: metadata.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
        NowPlaying.transport = c?.transportControls
        NowPlaying.update(title, artist, art, isPlaying)
        // refresh the home-screen widget
        PlayerWidget.refresh(applicationContext)
    }
}
