package com.malykbrown.musicwallpaper

import android.graphics.RenderEffect
import android.graphics.RuntimeShader
import android.graphics.Shader
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asComposeRenderEffect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * AGSL shader (API 33+) that warps its input with animated fractal-ish noise,
 * reproducing the liquid refraction from the HTML simulator.
 */
private const val LIQUID_AGSL = """
uniform shader content;
uniform float2 size;
uniform float time;
uniform float strength;

// cheap value noise
float hash(float2 p){ return fract(sin(dot(p, float2(41.3, 289.1))) * 43758.5453); }
float noise(float2 p){
    float2 i = floor(p); float2 f = fract(p);
    float2 u = f*f*(3.0-2.0*f);
    float a = hash(i);
    float b = hash(i+float2(1.0,0.0));
    float c = hash(i+float2(0.0,1.0));
    float d = hash(i+float2(1.0,1.0));
    return mix(mix(a,b,u.x), mix(c,d,u.x), u.y);
}

half4 main(float2 fragCoord){
    float2 uv = fragCoord / size;
    float n1 = noise(uv*6.0 + float2(time*0.15, time*0.10));
    float n2 = noise(uv*9.0 - float2(time*0.10, time*0.18));
    float2 disp = (float2(n1, n2) - 0.5) * strength;
    return content.eval(fragCoord + disp);
}
"""

/**
 * Applies the liquid-glass look:
 *  - backdrop blur via RenderEffect
 *  - refraction warp via the AGSL shader
 *  - translucent fill, soft top reflection, rounded rim
 *
 * @param time    animated seconds value (drive from a Compose animation)
 * @param tinted  dark gold tint vs clear
 */
fun Modifier.liquidGlass(
    time: Float,
    cornerRadius: Dp = 30.dp,
    blur: Dp = 3.dp,
    distortion: Float = 48f,
    tinted: Boolean = false,
    reflectionTop: Boolean = true,
): Modifier {
    val shape = RoundedCornerShape(cornerRadius)
    return this
        .clip(shape)
        .graphicsLayer {
            val shader = RuntimeShader(LIQUID_AGSL)
            shader.setFloatUniform("size", size.width, size.height)
            shader.setFloatUniform("time", time)
            shader.setFloatUniform("strength", distortion)
            val refract = RenderEffect.createRuntimeShaderEffect(shader, "content")
            val blurPx = blur.toPx()
            val blurFx = if (blurPx > 0f)
                RenderEffect.createBlurEffect(blurPx, blurPx, Shader.TileMode.CLAMP)
            else null
            renderEffect = (if (blurFx != null)
                RenderEffect.createChainEffect(refract, blurFx) else refract)
                .asComposeRenderEffect()
        }
        .background(
            color = if (tinted) Color(0x33141008) else Color(0x05FFFFFF),
            shape = shape
        )
        .then(
            if (reflectionTop) Modifier.background(
                brush = Brush.verticalGradient(
                    0f to Color(0x44FFFFFF),
                    0.45f to Color(0x11FFFFFF),
                    1f to Color.Transparent
                ),
                shape = shape
            ) else Modifier
        )
        .drawWithContent {
            drawContent()
            // moving specular light sweep, like the HTML version
            val sweep = ((time * 0.05f) % 1f)
            val cx = size.width * (sweep * 1.6f - 0.3f)
            val band = size.width * 0.22f
            drawRect(
                brush = Brush.linearGradient(
                    colors = listOf(Color.Transparent, Color(0x55FFFFFF), Color.Transparent),
                    start = Offset(cx - band, 0f),
                    end = Offset(cx + band, size.height)
                ),
                blendMode = BlendMode.Screen
            )
        }
}

fun Modifier.glassPadding() = this.padding(16.dp)
