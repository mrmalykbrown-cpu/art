package com.malykbrown.musicwallpaper

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

/**
 * Home-screen widget: album art, title/artist and prev/play/next controls.
 * Controls drive the active MediaSession via NowPlaying.transport.
 */
class PlayerWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, mgr: AppWidgetManager, ids: IntArray) {
        ids.forEach { id -> mgr.updateAppWidget(id, buildViews(context)) }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        val t = NowPlaying.transport
        when (intent.action) {
            ACTION_PLAY -> {
                val playing = NowPlaying.state.value.playing
                if (playing) t?.pause() else t?.play()
            }
            ACTION_PREV -> t?.skipToPrevious()
            ACTION_NEXT -> t?.skipToNext()
        }
        if (intent.action in setOf(ACTION_PLAY, ACTION_PREV, ACTION_NEXT)) {
            refresh(context)
        }
    }

    companion object {
        const val ACTION_PLAY = "com.malykbrown.musicwallpaper.PLAY"
        const val ACTION_PREV = "com.malykbrown.musicwallpaper.PREV"
        const val ACTION_NEXT = "com.malykbrown.musicwallpaper.NEXT"

        fun refresh(context: Context) {
            val mgr = AppWidgetManager.getInstance(context)
            val ids = mgr.getAppWidgetIds(
                android.content.ComponentName(context, PlayerWidget::class.java)
            )
            ids.forEach { id -> mgr.updateAppWidget(id, buildViews(context)) }
        }

        private fun pending(context: Context, action: String): PendingIntent {
            val intent = Intent(context, PlayerWidget::class.java).setAction(action)
            return PendingIntent.getBroadcast(
                context, action.hashCode(), intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }

        private fun buildViews(context: Context): RemoteViews {
            val v = RemoteViews(context.packageName, R.layout.widget_player)
            val info = NowPlaying.state.value
            v.setTextViewText(R.id.widget_title, info.title.ifEmpty { "Sem reproducao" })
            v.setTextViewText(R.id.widget_artist, info.artist.ifEmpty { "—" })
            info.art?.let { v.setImageViewBitmap(R.id.widget_cover, it) }
            v.setImageViewResource(
                R.id.widget_play,
                if (info.playing) android.R.drawable.ic_media_pause
                else android.R.drawable.ic_media_play
            )
            v.setOnClickPendingIntent(R.id.widget_prev, pending(context, ACTION_PREV))
            v.setOnClickPendingIntent(R.id.widget_play, pending(context, ACTION_PLAY))
            v.setOnClickPendingIntent(R.id.widget_next, pending(context, ACTION_NEXT))
            // tapping the cover opens the app
            val open = PendingIntent.getActivity(
                context, 0, Intent(context, MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            v.setOnClickPendingIntent(R.id.widget_cover, open)
            return v
        }
    }
}
