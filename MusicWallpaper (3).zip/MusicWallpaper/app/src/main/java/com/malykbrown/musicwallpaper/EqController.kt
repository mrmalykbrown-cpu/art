package com.malykbrown.musicwallpaper

import android.media.audiofx.Equalizer
import android.util.Log

/**
 * Wraps Android's global Equalizer (audio session 0).
 * Bands map to whatever the device exposes; presets are applied proportionally.
 *
 * Note: binding to session 0 affects the global mix on many devices. Some OEMs
 * restrict this — we fail gracefully so the UI sliders still move.
 */
class EqController {
    private var eq: Equalizer? = null
    var bandCount: Int = 0; private set
    var minLevel: Short = -1500; private set
    var maxLevel: Short = 1500; private set

    fun init() {
        if (eq != null) return
        try {
            eq = Equalizer(0, 0).apply {
                enabled = true
                this@EqController.bandCount = numberOfBands.toInt()
                val range = bandLevelRange
                minLevel = range[0]
                maxLevel = range[1]
            }
        } catch (e: Exception) {
            Log.w("EqController", "Equalizer unavailable: ${e.message}")
        }
    }

    /** centerFrequencies in Hz for labelling (falls back to standard 5-band). */
    fun centerFrequencies(): List<Int> {
        val e = eq ?: return listOf(60, 230, 910, 3600, 14000)
        return (0 until bandCount).map { e.getCenterFreq(it.toShort()) / 1000 }
    }

    /** set a band to a gain in dB (-12..12). */
    fun setBandDb(band: Int, db: Float) {
        val e = eq ?: return
        val level = (db / 12f * maxLevel).toInt()
            .coerceIn(minLevel.toInt(), maxLevel.toInt()).toShort()
        try { e.setBandLevel(band.toShort(), level) } catch (_: Exception) {}
    }

    fun applyPreset(dbValues: List<Float>) {
        for (i in 0 until bandCount) {
            val db = dbValues.getOrElse(i) { 0f }
            setBandDb(i, db)
        }
    }

    fun release() {
        try { eq?.release() } catch (_: Exception) {}
        eq = null
    }
}
