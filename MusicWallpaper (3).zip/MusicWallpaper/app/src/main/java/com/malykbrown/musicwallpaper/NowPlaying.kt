package com.malykbrown.musicwallpaper

import android.graphics.Bitmap
import android.media.session.MediaController
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class TrackInfo(
    val title: String = "",
    val artist: String = "",
    val art: Bitmap? = null,
    val artKey: String = "",
    val playing: Boolean = false
)

data class HistoryItem(val title: String, val artist: String, val time: String)

object NowPlaying {
    private val _state = MutableStateFlow(TrackInfo())
    val state: StateFlow<TrackInfo> = _state

    private val _history = MutableStateFlow<List<HistoryItem>>(emptyList())
    val history: StateFlow<List<HistoryItem>> = _history

    /** transport controls of the active session, for the widget/app to drive playback */
    @Volatile var transport: MediaController.TransportControls? = null

    private val timeFmt = SimpleDateFormat("HH:mm", Locale.getDefault())

    fun update(title: String, artist: String, art: Bitmap?, playing: Boolean) {
        val key = "$title|$artist|${art?.width}x${art?.height}"
        if (key == _state.value.artKey && playing == _state.value.playing) return
        val isNewTrack = key != _state.value.artKey
        _state.value = TrackInfo(title, artist, art, key, playing)
        if (isNewTrack && title.isNotEmpty()) {
            val item = HistoryItem(title, artist, timeFmt.format(Date()))
            _history.value = (listOf(item) + _history.value).take(15)
        }
    }
}
