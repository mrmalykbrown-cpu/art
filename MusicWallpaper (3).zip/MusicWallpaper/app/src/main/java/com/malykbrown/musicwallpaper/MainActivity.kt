package com.malykbrown.musicwallpaper

import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asComposeRenderEffect
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle

private val Gold = Color(0xFFD4A437)
private val GoldBright = Color(0xFFF0C75E)
private val Bone = Color(0xFFEDE6D6)

class MainActivity : ComponentActivity() {
    private val eq = EqController()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        eq.init()
        setContent {
            AppRoot(
                eq = eq,
                onOpenNotifAccess = { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) },
                onSetWallpaper = {
                    val intent = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).apply {
                        putExtra(
                            WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                            ComponentName(this@MainActivity, MusicWallpaperService::class.java)
                        )
                    }
                    startActivity(intent)
                }
            )
        }
    }

    override fun onDestroy() { eq.release(); super.onDestroy() }
}

private enum class Tab(val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Home(Icons.Filled.Home),
    Eq(Icons.Filled.GraphicEq),
    History(Icons.Filled.History),
    Profile(Icons.Filled.Person)
}

@Composable
fun AppRoot(eq: EqController, onOpenNotifAccess: () -> Unit, onSetWallpaper: () -> Unit) {
    var tab by remember { mutableStateOf(Tab.Home) }
    var tinted by remember { mutableStateOf(false) }

    val infinite = rememberInfiniteTransition(label = "glass")
    val time by infinite.animateFloat(
        initialValue = 0f, targetValue = 100f,
        animationSpec = infiniteRepeatable(tween(40000, easing = LinearEasing)),
        label = "time"
    )

    val now by NowPlaying.state.collectAsStateWithLifecycle()

    Box(Modifier.fillMaxSize().background(Color(0xFF07070A))) {
        // live album-art backdrop (blurred fill), like the wallpaper showing through
        AlbumBackdrop(now)

        Column(
            Modifier.fillMaxSize().padding(bottom = 96.dp)
                .padding(WindowInsets.statusBars.asPaddingValues())
        ) {
            when (tab) {
                Tab.Home -> HomeScreen(time, tinted, now, onOpenNotifAccess, onSetWallpaper) { tinted = !tinted }
                Tab.Eq -> EqScreen(time, tinted, eq)
                Tab.History -> HistoryScreen(time, tinted)
                Tab.Profile -> ProfileScreen(time, tinted)
            }
        }
        Dock(
            time = time, tinted = tinted, selected = tab,
            modifier = Modifier.align(Alignment.BottomCenter).navigationBarsPadding(),
            onSelect = { tab = it }
        )
    }
}

@Composable
private fun AlbumBackdrop(now: TrackInfo) {
    val art = now.art
    if (art != null) {
        androidx.compose.foundation.Image(
            bitmap = art.asImageBitmap(),
            contentDescription = null,
            contentScale = androidx.compose.ui.layout.ContentScale.Crop,
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    renderEffect = android.graphics.RenderEffect
                        .createBlurEffect(60f, 60f, android.graphics.Shader.TileMode.CLAMP)
                        .asComposeRenderEffect()
                }
        )
        Box(Modifier.fillMaxSize().background(Color(0x2E000000)))
    } else {
        Box(
            Modifier.fillMaxSize().background(
                androidx.compose.ui.graphics.Brush.linearGradient(
                    listOf(Color(0xFF1C1812), Color(0xFF07070A))
                )
            )
        )
    }
}

@Composable
private fun HomeScreen(
    time: Float, tinted: Boolean, now: TrackInfo,
    onNotif: () -> Unit, onWall: () -> Unit, onToggleTint: () -> Unit
) {
    Column(
        Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Music Wallpaper", color = GoldBright, fontSize = 24.sp, fontWeight = FontWeight.Medium)
        GlassCard(time, tinted) {
            val status = if (now.title.isEmpty()) "Toca uma musica para ver a arte e os controlos."
                         else "${now.title} - ${now.artist}"
            Text(status, color = Bone, fontSize = 14.sp)
        }
        GlassButton(time, tinted, "1. Activar acesso as notificacoes", onNotif)
        GlassButton(time, tinted, "2. Definir como papel de parede", onWall)
        PlayerWidget(time, tinted, now)
        GlassButton(time, tinted, if (tinted) "Vidro: Tingido" else "Vidro: Transparente", onToggleTint)
    }
}

@Composable
private fun PlayerWidget(time: Float, tinted: Boolean, now: TrackInfo) {
    var playing by remember { mutableStateOf(true) }
    var progress by remember { mutableStateOf(0.35f) }
    var dragging by remember { mutableStateOf(false) }

    GlassCard(time, tinted) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(52.dp).clip(RoundedCornerShape(13.dp)).background(Gold))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(now.title.ifEmpty { "Sem reproducao" },
                    color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1)
                Text(now.artist.ifEmpty { "-" }, color = Color(0xCCFFFFFF), fontSize = 13.sp, maxLines = 1)
            }
        }
        Spacer(Modifier.height(14.dp))
        val barHeight = if (dragging) 8.dp else 6.dp
        Box(
            Modifier.fillMaxWidth().height(20.dp).pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { dragging = true },
                    onDragEnd = { dragging = false },
                    onDrag = { change, _ ->
                        progress = (change.position.x / size.width).coerceIn(0f, 1f)
                    }
                )
            },
            contentAlignment = Alignment.CenterStart
        ) {
            Box(Modifier.fillMaxWidth().height(barHeight).clip(RoundedCornerShape(99.dp)).background(Color(0x39FFFFFF)))
            Box(Modifier.fillMaxWidth(progress).height(barHeight).clip(RoundedCornerShape(99.dp)).background(Color.White))
            if (dragging) {
                Box(Modifier.fillMaxWidth(progress).height(barHeight), contentAlignment = Alignment.CenterEnd) {
                    Box(Modifier.size(16.dp).liquidGlass(time, cornerRadius = 8.dp, blur = 2.dp, distortion = 20f))
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = {}) {
                Icon(Icons.Filled.FastRewind, "Anterior", tint = Color.White, modifier = Modifier.size(30.dp))
            }
            Spacer(Modifier.width(28.dp))
            IconButton(onClick = { playing = !playing }) {
                Icon(if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                    "Play", tint = Color.White, modifier = Modifier.size(40.dp))
            }
            Spacer(Modifier.width(28.dp))
            IconButton(onClick = {}) {
                Icon(Icons.Filled.FastForward, "Seguinte", tint = Color.White, modifier = Modifier.size(30.dp))
            }
        }
    }
}

@Composable
private fun EqScreen(time: Float, tinted: Boolean, eq: EqController) {
    val freqs = remember { eq.centerFrequencies() }
    val n = freqs.size.coerceAtLeast(1)
    val gains = remember { mutableStateListOf<Float>().apply { repeat(n) { add(0f) } } }

    Column(
        Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Equalizador", color = GoldBright, fontSize = 22.sp, fontWeight = FontWeight.Medium)
        GlassCard(time, tinted) {
            Row(Modifier.fillMaxWidth().height(180.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                freqs.forEachIndexed { i, hz ->
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                        Slider(
                            value = gains.getOrElse(i) { 0f },
                            onValueChange = { v -> if (i < gains.size) gains[i] = v; eq.setBandDb(i, v) },
                            valueRange = -12f..12f,
                            modifier = Modifier.weight(1f),
                            colors = SliderDefaults.colors(
                                thumbColor = GoldBright, activeTrackColor = Gold, inactiveTrackColor = Color(0x33FFFFFF)
                            )
                        )
                        Text(if (hz >= 1000) "${hz / 1000}k" else "$hz", color = Color(0xB3FFFFFF), fontSize = 10.sp)
                    }
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            EqPresetButton(time, tinted, "Flat", Modifier.weight(1f)) { applyPreset(eq, gains, List(n) { 0f }) }
            EqPresetButton(time, tinted, "Bass", Modifier.weight(1f)) { applyPreset(eq, gains, presetFor(n, "bass")) }
            EqPresetButton(time, tinted, "Vocal", Modifier.weight(1f)) { applyPreset(eq, gains, presetFor(n, "vocal")) }
        }
        Text(
            "O equalizador actua na sessao de audio global. Alguns telemoveis restringem isto.",
            color = Color(0x99FFFFFF), fontSize = 11.sp
        )
    }
}

private fun presetFor(n: Int, kind: String): List<Float> {
    val bass = listOf(10f, 7f, 3f, 0f, -1f, -1f, 0f)
    val vocal = listOf(-4f, -2f, 2f, 5f, 6f, 3f, 0f)
    val src = if (kind == "bass") bass else vocal
    return List(n) { src.getOrElse((it * src.size) / n) { 0f } }
}
private fun applyPreset(eq: EqController, gains: MutableList<Float>, values: List<Float>) {
    values.forEachIndexed { i, v -> if (i < gains.size) gains[i] = v }
    eq.applyPreset(values)
}

@Composable
private fun HistoryScreen(time: Float, tinted: Boolean) {
    Column(
        Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Historico", color = GoldBright, fontSize = 22.sp, fontWeight = FontWeight.Medium)
        val hist by NowPlaying.history.collectAsStateWithLifecycle()
        GlassCard(time, tinted) {
            if (hist.isEmpty()) {
                Text("Sem faixas ainda. Toca musica para preencher o historico.", color = Color(0x99FFFFFF), fontSize = 13.sp)
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    hist.forEach { h ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(38.dp).clip(RoundedCornerShape(9.dp)).background(Gold))
                            Spacer(Modifier.width(11.dp))
                            Column(Modifier.weight(1f)) {
                                Text(h.title, color = Color.White, fontSize = 13.sp, maxLines = 1)
                                Text(h.artist, color = Color(0xA6FFFFFF), fontSize = 11.sp, maxLines = 1)
                            }
                            Text(h.time, color = Color(0x8CFFFFFF), fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ProfileScreen(time: Float, tinted: Boolean) {
    Column(
        Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Perfil", color = GoldBright, fontSize = 22.sp, fontWeight = FontWeight.Medium)
        GlassCard(time, tinted) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(58.dp).clip(CircleShape).background(Gold), contentAlignment = Alignment.Center) {
                    Text("M", color = Color(0xFF15110A), fontSize = 24.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.width(13.dp))
                Column {
                    Text("Malyk Brown", color = Color.White, fontSize = 16.sp)
                    Text("Membro desde 2026", color = Color(0xB3FFFFFF), fontSize = 12.sp)
                }
            }
        }
        val hist by NowPlaying.history.collectAsStateWithLifecycle()
        GlassCard(time, tinted) {
            StatRow("Faixas ouvidas", "${hist.size}")
            StatRow("Estilo de vidro", if (tinted) "Tingido" else "Transparente")
        }
    }
}

@Composable
private fun StatRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = Color(0xD9FFFFFF), fontSize = 13.sp)
        Text(value, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun Dock(time: Float, tinted: Boolean, selected: Tab, modifier: Modifier = Modifier, onSelect: (Tab) -> Unit) {
    val tabs = Tab.values()
    val index = tabs.indexOf(selected)
    val slidePos by animateFloatAsState(
        targetValue = index.toFloat(),
        animationSpec = spring(dampingRatio = 0.6f, stiffness = 250f),
        label = "slide"
    )
    Box(
        modifier.fillMaxWidth().height(72.dp)
            .liquidGlass(time, cornerRadius = 0.dp, blur = 6.dp, distortion = 30f, tinted = tinted)
    ) {
        BoxWithConstraints(Modifier.fillMaxSize()) {
            val cell = maxWidth / tabs.size
            Box(
                Modifier.padding(top = 8.dp)
                    .offset(x = cell * slidePos + (cell - 46.dp) / 2)
                    .size(46.dp, 40.dp)
                    .liquidGlass(time, cornerRadius = 22.dp, blur = 6.dp, distortion = 24f, tinted = tinted)
            )
            Row(Modifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically) {
                tabs.forEach { t ->
                    Box(Modifier.weight(1f).fillMaxHeight().clickable { onSelect(t) }, contentAlignment = Alignment.Center) {
                        Icon(t.icon, t.name,
                            tint = if (t == selected) Color.White else Color(0xA6FFFFFF),
                            modifier = Modifier.size(24.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun GlassCard(time: Float, tinted: Boolean, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().liquidGlass(time, tinted = tinted).padding(16.dp),
        content = content
    )
}

@Composable
private fun GlassButton(time: Float, tinted: Boolean, label: String, onClick: () -> Unit) {
    Box(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(99.dp))
            .liquidGlass(time, cornerRadius = 99.dp, tinted = tinted)
            .clickable { onClick() }.padding(vertical = 14.dp),
        contentAlignment = Alignment.Center
    ) { Text(label, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium) }
}

@Composable
private fun EqPresetButton(time: Float, tinted: Boolean, label: String, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier.clip(RoundedCornerShape(16.dp))
            .liquidGlass(time, cornerRadius = 16.dp, tinted = tinted)
            .clickable { onClick() }.padding(vertical = 11.dp),
        contentAlignment = Alignment.Center
    ) { Text(label, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium) }
}
