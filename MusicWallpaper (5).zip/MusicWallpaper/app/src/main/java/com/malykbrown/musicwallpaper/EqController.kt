package com.malykbrown.musicwallpaper

import android.media.audiofx.Equalizer
import android.util.Log

class EqController {
    private var eq: Equalizer? = null
    var bandCount = 0; private set
    private var minLevel: Short = -1500
    private var maxLevel: Short = 1500

    fun init() {
        if (eq != null) return
        try {
            eq = Equalizer(0, 0).apply {
                enabled = true
                this@EqController.bandCount = numberOfBands.toInt()
                val r = bandLevelRange; minLevel = r[0]; maxLevel = r[1]
            }
        } catch (e: Exception) { Log.w("EqController", "unavailable: ${e.message}") }
    }
    fun centerFrequencies(): List<Int> {
        val e = eq ?: return listOf(60, 230, 910, 3600, 14000)
        return (0 until bandCount).map { e.getCenterFreq(it.toShort()) / 1000 }
    }
    fun setBandDb(band: Int, db: Float) {
        val e = eq ?: return
        val lvl = (db / 12f * maxLevel).toInt().coerceIn(minLevel.toInt(), maxLevel.toInt()).toShort()
        try { e.setBandLevel(band.toShort(), lvl) } catch (_: Exception) {}
    }
    fun applyPreset(vals: List<Float>) { for (i in 0 until bandCount) setBandDb(i, vals.getOrElse(i){0f}) }
    fun release() { try { eq?.release() } catch (_: Exception) {}; eq = null }
}
