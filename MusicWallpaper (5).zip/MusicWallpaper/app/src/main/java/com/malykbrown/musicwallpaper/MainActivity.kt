package com.malykbrown.musicwallpaper

import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RenderEffect
import androidx.compose.ui.graphics.Shader
import androidx.compose.ui.graphics.asComposeRenderEffect
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle

private val Gold = Color(0xFFD4A437)
private val GoldBright = Color(0xFFF0C75E)
private val Bone = Color(0xFFEDE6D6)

class MainActivity : ComponentActivity() {
    private val eq = EqController()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        eq.init()
        setContent {
            App(eq,
                { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) },
                {
                    startActivity(Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).putExtra(
                        WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                        ComponentName(this, MusicWallpaperService::class.java)
                    ))
                })
        }
    }
    override fun onDestroy() { eq.release(); super.onDestroy() }
}

private enum class Tab(val icon: ImageVector) {
    Home(Icons.Filled.Home), Eq(Icons.Filled.GraphicEq),
    History(Icons.Filled.History), Profile(Icons.Filled.Person)
}

@Composable
fun App(eq: EqController, onNotif: () -> Unit, onWall: () -> Unit) {
    var tab by remember { mutableStateOf(Tab.Home) }
    var tinted by remember { mutableStateOf(false) }
    val anim = rememberInfiniteTransition(label = "g")
    val time by anim.animateFloat(0f, 100f,
        infiniteRepeatable(tween(40000, easing = LinearEasing)), label = "t")
    val now by NowPlaying.state.collectAsStateWithLifecycle()

    Box(Modifier.fillMaxSize().background(Color(0xFF07070A))) {
        Backdrop(now)
        Column(Modifier.fillMaxSize().padding(bottom = 96.dp)
            .padding(WindowInsets.statusBars.asPaddingValues())) {
            when (tab) {
                Tab.Home -> Home(time, tinted, now, onNotif, onWall) { tinted = !tinted }
                Tab.Eq -> EqScreen(time, tinted, eq)
                Tab.History -> HistoryScreen(time, tinted)
                Tab.Profile -> ProfileScreen(time, tinted)
            }
        }
        Dock(time, tinted, tab, Modifier.align(Alignment.BottomCenter).navigationBarsPadding()) { tab = it }
    }
}

@Composable
private fun Backdrop(now: TrackInfo) {
    val art = now.art
    if (art != null) {
        Image(art.asImageBitmap(), null, contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize().graphicsLayer {
                renderEffect = RenderEffect.createBlurEffect(60f, 60f, Shader.TileMode.CLAMP)
                    .asComposeRenderEffect()
            })
        Box(Modifier.fillMaxSize().background(Color(0x2E000000)))
    } else {
        Box(Modifier.fillMaxSize().background(
            Brush.linearGradient(listOf(Color(0xFF1C1812), Color(0xFF07070A)))))
    }
}

@Composable
private fun Home(time: Float, tinted: Boolean, now: TrackInfo,
                 onNotif: () -> Unit, onWall: () -> Unit, onTint: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Music Wallpaper", color = GoldBright, fontSize = 24.sp, fontWeight = FontWeight.Medium)
        GlassCard(time, tinted) {
            Text(if (now.title.isEmpty()) "Toca uma musica para comecar." else "${now.title} - ${now.artist}",
                color = Bone, fontSize = 14.sp)
        }
        GlassButton(time, tinted, "1. Activar acesso as notificacoes", onNotif)
        GlassButton(time, tinted, "2. Definir como papel de parede", onWall)
        Player(time, tinted, now)
        GlassButton(time, tinted, if (tinted) "Vidro: Tingido" else "Vidro: Transparente", onTint)
    }
}

@Composable
private fun Player(time: Float, tinted: Boolean, now: TrackInfo) {
    var playing by remember { mutableStateOf(true) }
    var progress by remember { mutableStateOf(0.35f) }
    var dragging by remember { mutableStateOf(false) }
    GlassCard(time, tinted) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(52.dp).clip(RoundedCornerShape(13.dp)).background(Gold))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(now.title.ifEmpty { "Sem reproducao" }, color = Color.White,
                    fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1)
                Text(now.artist.ifEmpty { "-" }, color = Color(0xCCFFFFFF), fontSize = 13.sp, maxLines = 1)
            }
        }
        Spacer(Modifier.height(14.dp))
        val bh = if (dragging) 8.dp else 6.dp
        Box(Modifier.fillMaxWidth().height(20.dp).pointerInput(Unit) {
            detectDragGestures(onDragStart = { dragging = true }, onDragEnd = { dragging = false },
                onDrag = { c, _ -> progress = (c.position.x / size.width).coerceIn(0f, 1f) })
        }, contentAlignment = Alignment.CenterStart) {
            Box(Modifier.fillMaxWidth().height(bh).clip(RoundedCornerShape(99.dp)).background(Color(0x39FFFFFF)))
            Box(Modifier.fillMaxWidth(progress).height(bh).clip(RoundedCornerShape(99.dp)).background(Color.White))
            if (dragging) Box(Modifier.fillMaxWidth(progress).height(bh), contentAlignment = Alignment.CenterEnd) {
                Box(Modifier.size(16.dp).liquidGlass(time, 8.dp, 2.dp, 20f))
            }
        }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically) {
            IconButton({}) { Icon(Icons.Filled.FastRewind, "prev", tint = Color.White, modifier = Modifier.size(30.dp)) }
            Spacer(Modifier.width(28.dp))
            IconButton({ playing = !playing }) {
                Icon(if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, "play",
                    tint = Color.White, modifier = Modifier.size(40.dp))
            }
            Spacer(Modifier.width(28.dp))
            IconButton({}) { Icon(Icons.Filled.FastForward, "next", tint = Color.White, modifier = Modifier.size(30.dp)) }
        }
    }
}

@Composable
private fun EqScreen(time: Float, tinted: Boolean, eq: EqController) {
    val freqs = remember { eq.centerFrequencies() }
    val n = freqs.size.coerceAtLeast(1)
    val gains = remember { mutableStateListOf<Float>().apply { repeat(n) { add(0f) } } }
    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Equalizador", color = GoldBright, fontSize = 22.sp, fontWeight = FontWeight.Medium)
        GlassCard(time, tinted) {
            Row(Modifier.fillMaxWidth().height(170.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                freqs.forEachIndexed { i, hz ->
                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                        Slider(gains.getOrElse(i) { 0f },
                            { v -> if (i < gains.size) gains[i] = v; eq.setBandDb(i, v) },
                            valueRange = -12f..12f, modifier = Modifier.weight(1f),
                            colors = SliderDefaults.colors(thumbColor = GoldBright,
                                activeTrackColor = Gold, inactiveTrackColor = Color(0x33FFFFFF)))
                        Text(if (hz >= 1000) "${hz/1000}k" else "$hz", color = Color(0xB3FFFFFF), fontSize = 10.sp)
                    }
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Preset(time, tinted, "Flat", Modifier.weight(1f)) { apply(eq, gains, List(n){0f}) }
            Preset(time, tinted, "Bass", Modifier.weight(1f)) { apply(eq, gains, pre(n,"bass")) }
            Preset(time, tinted, "Vocal", Modifier.weight(1f)) { apply(eq, gains, pre(n,"vocal")) }
        }
        Text("O equalizador actua na sessao de audio global. Alguns telemoveis restringem isto.",
            color = Color(0x99FFFFFF), fontSize = 11.sp)
    }
}
private fun pre(n: Int, k: String): List<Float> {
    val b = listOf(10f,7f,3f,0f,-1f,-1f,0f); val v = listOf(-4f,-2f,2f,5f,6f,3f,0f)
    val s = if (k=="bass") b else v
    return List(n) { s.getOrElse((it*s.size)/n){0f} }
}
private fun apply(eq: EqController, g: MutableList<Float>, vals: List<Float>) {
    vals.forEachIndexed { i, x -> if (i < g.size) g[i] = x }; eq.applyPreset(vals)
}

@Composable
private fun HistoryScreen(time: Float, tinted: Boolean) {
    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Historico", color = GoldBright, fontSize = 22.sp, fontWeight = FontWeight.Medium)
        val hist by NowPlaying.history.collectAsStateWithLifecycle()
        GlassCard(time, tinted) {
            if (hist.isEmpty()) Text("Sem faixas ainda.", color = Color(0x99FFFFFF), fontSize = 13.sp)
            else Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                hist.forEach { h ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(38.dp).clip(RoundedCornerShape(9.dp)).background(Gold))
                        Spacer(Modifier.width(11.dp))
                        Column(Modifier.weight(1f)) {
                            Text(h.title, color = Color.White, fontSize = 13.sp, maxLines = 1)
                            Text(h.artist, color = Color(0xA6FFFFFF), fontSize = 11.sp, maxLines = 1)
                        }
                        Text(h.time, color = Color(0x8CFFFFFF), fontSize = 11.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun ProfileScreen(time: Float, tinted: Boolean) {
    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Perfil", color = GoldBright, fontSize = 22.sp, fontWeight = FontWeight.Medium)
        GlassCard(time, tinted) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(58.dp).clip(CircleShape).background(Gold), contentAlignment = Alignment.Center) {
                    Text("M", color = Color(0xFF15110A), fontSize = 24.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.width(13.dp))
                Column {
                    Text("Malyk Brown", color = Color.White, fontSize = 16.sp)
                    Text("Membro desde 2026", color = Color(0xB3FFFFFF), fontSize = 12.sp)
                }
            }
        }
        val hist by NowPlaying.history.collectAsStateWithLifecycle()
        GlassCard(time, tinted) {
            Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Faixas ouvidas", color = Color(0xD9FFFFFF), fontSize = 13.sp)
                Text("${hist.size}", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
            }
        }
    }
}

@Composable
private fun Dock(time: Float, tinted: Boolean, sel: Tab, modifier: Modifier, onSel: (Tab) -> Unit) {
    val tabs = Tab.values()
    val idx = tabs.indexOf(sel)
    val pos by animateFloatAsState(idx.toFloat(),
        spring(dampingRatio = 0.6f, stiffness = 250f), label = "s")
    Box(modifier.fillMaxWidth().height(72.dp).liquidGlass(time, 0.dp, 6.dp, 30f, tinted)) {
        BoxWithConstraints(Modifier.fillMaxSize()) {
            val cell = maxWidth / tabs.size
            Box(Modifier.padding(top = 8.dp)
                .offset(x = cell * pos + (cell - 46.dp) / 2)
                .size(46.dp, 40.dp).liquidGlass(time, 22.dp, 6.dp, 24f, tinted))
            Row(Modifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically) {
                tabs.forEach { t ->
                    Box(Modifier.weight(1f).fillMaxHeight().clickable { onSel(t) },
                        contentAlignment = Alignment.Center) {
                        Icon(t.icon, t.name, tint = if (t == sel) Color.White else Color(0xA6FFFFFF),
                            modifier = Modifier.size(24.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun GlassCard(time: Float, tinted: Boolean, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().liquidGlass(time, tinted = tinted).padding(16.dp), content = content)
}
@Composable
private fun GlassButton(time: Float, tinted: Boolean, label: String, onClick: () -> Unit) {
    Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(99.dp)).liquidGlass(time, 99.dp, tinted = tinted)
        .clickable { onClick() }.padding(vertical = 14.dp), contentAlignment = Alignment.Center) {
        Text(label, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
    }
}
@Composable
private fun Preset(time: Float, tinted: Boolean, label: String, modifier: Modifier, onClick: () -> Unit) {
    Box(modifier.clip(RoundedCornerShape(16.dp)).liquidGlass(time, 16.dp, tinted = tinted)
        .clickable { onClick() }.padding(vertical = 11.dp), contentAlignment = Alignment.Center) {
        Text(label, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}
