package com.malykbrown.musicwallpaper

import android.animation.ValueAnimator
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder
import android.view.animation.DecelerateInterpolator
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlin.math.max
import kotlin.math.roundToInt

class MusicWallpaperService : WallpaperService() {
    override fun onCreateEngine(): Engine = MusicEngine()

    inner class MusicEngine : Engine() {
        private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
        private var job: Job? = null
        private var current: Bitmap? = null
        private var incoming: Bitmap? = null
        private var fade = 1f
        private var anim: ValueAnimator? = null
        private var w = 0; private var h = 0
        private val paint = Paint(Paint.FILTER_BITMAP_FLAG)

        override fun onSurfaceChanged(holder: SurfaceHolder, f: Int, width: Int, height: Int) {
            w = width; h = height
            NowPlaying.state.value.art?.let { setArt(it, false) } ?: draw()
        }
        override fun onVisibilityChanged(visible: Boolean) {
            if (visible) { collect(); draw() } else { job?.cancel(); anim?.cancel() }
        }
        override fun onDestroy() { job?.cancel(); anim?.cancel(); super.onDestroy() }

        private fun collect() {
            if (job?.isActive == true) return
            job = scope.launch { NowPlaying.state.collect { it.art?.let { a -> setArt(a, true) } } }
        }
        private fun setArt(art: Bitmap, animate: Boolean) {
            if (w <= 0 || h <= 0) return
            scope.launch {
                val composed = compose(art, w, h)
                if (!animate || current == null) { current = composed; incoming = null; fade = 1f; draw() }
                else { incoming = composed; crossfade() }
            }
        }
        private fun crossfade() {
            anim?.cancel(); fade = 0f
            anim = ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 900; interpolator = DecelerateInterpolator()
                addUpdateListener {
                    fade = it.animatedValue as Float; draw()
                    if (fade >= 1f) { current = incoming ?: current; incoming = null }
                }
                start()
            }
        }
        private fun compose(art: Bitmap, w: Int, h: Int): Bitmap {
            val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val c = Canvas(out)
            val scale = max(w.toFloat() / art.width, h.toFloat() / art.height)
            val sw = (art.width * scale).roundToInt(); val sh = (art.height * scale).roundToInt()
            val scaled = Bitmap.createScaledBitmap(art, sw, sh, true)
            val x = (sw - w) / 2; val y = (sh - h) / 2
            c.drawBitmap(scaled, Rect(x, y, x + w, y + h), Rect(0, 0, w, h), paint)
            c.drawColor(Color.argb(46, 0, 0, 0))
            return out
        }
        private fun draw() {
            val holder = surfaceHolder ?: return
            var canvas: Canvas? = null
            try {
                canvas = holder.lockCanvas() ?: return
                canvas.drawColor(Color.BLACK)
                current?.let { paint.alpha = 255; canvas.drawBitmap(it, 0f, 0f, paint) }
                incoming?.let {
                    paint.alpha = (fade * 255).toInt().coerceIn(0, 255)
                    canvas.drawBitmap(it, 0f, 0f, paint); paint.alpha = 255
                }
            } finally {
                if (canvas != null) try { holder.unlockCanvasAndPost(canvas) } catch (_: Exception) {}
            }
        }
    }
}
