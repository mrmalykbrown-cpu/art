package com.malykbrown.musicwallpaper

import android.graphics.Bitmap
import android.media.session.MediaController
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class TrackInfo(
    val title: String = "",
    val artist: String = "",
    val art: Bitmap? = null,
    val playing: Boolean = false,
    val key: String = ""
)

data class HistoryItem(val title: String, val artist: String, val time: String)

object NowPlaying {
    private val _state = MutableStateFlow(TrackInfo())
    val state: StateFlow<TrackInfo> = _state

    private val _history = MutableStateFlow<List<HistoryItem>>(emptyList())
    val history: StateFlow<List<HistoryItem>> = _history

    @Volatile var transport: MediaController.TransportControls? = null

    private val fmt = SimpleDateFormat("HH:mm", Locale.getDefault())

    fun update(title: String, artist: String, art: Bitmap?, playing: Boolean) {
        val k = "$title|$artist|$playing"
        if (k == _state.value.key) return
        val titleChanged = title != _state.value.title
        _state.value = TrackInfo(title, artist, art, playing, k)
        if (title.isNotEmpty() && titleChanged) {
            _history.value = (listOf(HistoryItem(title, artist, fmt.format(Date()))) + _history.value).take(15)
        }
    }
}
