package com.malykbrown.musicwallpaper

import android.graphics.RenderEffect
import android.graphics.RuntimeShader
import android.graphics.Shader
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asComposeRenderEffect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

private const val AGSL = """
uniform shader content;
uniform float2 size;
uniform float time;
uniform float strength;
float hash(float2 p){ return fract(sin(dot(p, float2(41.3, 289.1))) * 43758.5453); }
float noise(float2 p){
    float2 i = floor(p); float2 f = fract(p);
    float2 u = f*f*(3.0-2.0*f);
    return mix(mix(hash(i), hash(i+float2(1,0)), u.x),
               mix(hash(i+float2(0,1)), hash(i+float2(1,1)), u.x), u.y);
}
half4 main(float2 fragCoord){
    float2 uv = fragCoord / size;
    float n1 = noise(uv*6.0 + float2(time*0.15, time*0.10));
    float n2 = noise(uv*9.0 - float2(time*0.10, time*0.18));
    float2 disp = (float2(n1, n2) - 0.5) * strength;
    return content.eval(fragCoord + disp);
}
"""

fun Modifier.liquidGlass(
    time: Float,
    cornerRadius: Dp = 30.dp,
    blur: Dp = 3.dp,
    distortion: Float = 40f,
    tinted: Boolean = false,
): Modifier {
    val shape = RoundedCornerShape(cornerRadius)
    return this
        .clip(shape)
        .graphicsLayer {
            val shader = RuntimeShader(AGSL)
            shader.setFloatUniform("size", size.width, size.height)
            shader.setFloatUniform("time", time)
            shader.setFloatUniform("strength", distortion)
            val refract = RenderEffect.createRuntimeShaderEffect(shader, "content")
            val blurPx = blur.toPx()
            renderEffect = if (blurPx > 0f)
                RenderEffect.createChainEffect(
                    refract,
                    RenderEffect.createBlurEffect(blurPx, blurPx, Shader.TileMode.CLAMP)
                ).asComposeRenderEffect()
            else refract.asComposeRenderEffect()
        }
        .background(if (tinted) Color(0x33141008) else Color(0x0DFFFFFF), shape)
        .background(
            Brush.verticalGradient(
                0f to Color(0x40FFFFFF), 0.45f to Color(0x10FFFFFF), 1f to Color.Transparent
            ), shape
        )
        .drawWithContent {
            drawContent()
            val sweep = (time * 0.05f) % 1f
            val cx = size.width * (sweep * 1.6f - 0.3f)
            val band = size.width * 0.22f
            drawRect(
                brush = Brush.linearGradient(
                    listOf(Color.Transparent, Color(0x55FFFFFF), Color.Transparent),
                    start = Offset(cx - band, 0f), end = Offset(cx + band, size.height)
                ),
                blendMode = BlendMode.Screen
            )
        }
}
