package com.malykbrown.musicwallpaper

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

class MusicWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, mgr: AppWidgetManager, ids: IntArray) {
        ids.forEach { mgr.updateAppWidget(it, build(context)) }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        val t = NowPlaying.transport
        when (intent.action) {
            ACTION_PLAY -> if (NowPlaying.state.value.playing) t?.pause() else t?.play()
            ACTION_PREV -> t?.skipToPrevious()
            ACTION_NEXT -> t?.skipToNext()
        }
        if (intent.action in setOf(ACTION_PLAY, ACTION_PREV, ACTION_NEXT)) refresh(context)
    }

    companion object {
        const val ACTION_PLAY = "com.malykbrown.musicwallpaper.PLAY"
        const val ACTION_PREV = "com.malykbrown.musicwallpaper.PREV"
        const val ACTION_NEXT = "com.malykbrown.musicwallpaper.NEXT"

        fun refresh(context: Context) {
            val mgr = AppWidgetManager.getInstance(context)
            mgr.getAppWidgetIds(ComponentName(context, MusicWidget::class.java))
                .forEach { mgr.updateAppWidget(it, build(context)) }
        }
        private fun pi(context: Context, action: String): PendingIntent {
            val i = Intent(context, MusicWidget::class.java).setAction(action)
            return PendingIntent.getBroadcast(
                context, action.hashCode(), i,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }
        private fun build(context: Context): RemoteViews {
            val v = RemoteViews(context.packageName, R.layout.widget_player)
            val s = NowPlaying.state.value
            v.setTextViewText(R.id.widget_title, s.title.ifEmpty { "Sem reproducao" })
            v.setTextViewText(R.id.widget_artist, s.artist.ifEmpty { "-" })
            s.art?.let { v.setImageViewBitmap(R.id.widget_cover, it) }
            v.setImageViewResource(
                R.id.widget_play,
                if (s.playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
            )
            v.setOnClickPendingIntent(R.id.widget_prev, pi(context, ACTION_PREV))
            v.setOnClickPendingIntent(R.id.widget_play, pi(context, ACTION_PLAY))
            v.setOnClickPendingIntent(R.id.widget_next, pi(context, ACTION_NEXT))
            v.setOnClickPendingIntent(
                R.id.widget_cover,
                PendingIntent.getActivity(
                    context, 0, Intent(context, MainActivity::class.java),
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
            )
            return v
        }
    }
}
