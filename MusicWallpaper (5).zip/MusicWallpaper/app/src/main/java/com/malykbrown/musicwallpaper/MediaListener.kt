package com.malykbrown.musicwallpaper

import android.content.ComponentName
import android.graphics.Bitmap
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.service.notification.NotificationListenerService

class MediaListener : NotificationListenerService() {

    private var manager: MediaSessionManager? = null
    private var controller: MediaController? = null

    private val cb = object : MediaController.Callback() {
        override fun onMetadataChanged(m: MediaMetadata?) = push()
        override fun onPlaybackStateChanged(s: PlaybackState?) = refresh()
    }

    private val listener = MediaSessionManager.OnActiveSessionsChangedListener { refresh() }

    override fun onListenerConnected() {
        super.onListenerConnected()
        manager = getSystemService(MediaSessionManager::class.java)
        try {
            manager?.addOnActiveSessionsChangedListener(
                listener, ComponentName(this, MediaListener::class.java)
            )
        } catch (_: SecurityException) {}
        refresh()
    }

    override fun onListenerDisconnected() {
        manager?.removeOnActiveSessionsChangedListener(listener)
        controller?.unregisterCallback(cb); controller = null
        NowPlaying.transport = null
        super.onListenerDisconnected()
    }

    private fun refresh() {
        val comp = ComponentName(this, MediaListener::class.java)
        val sessions = try { manager?.getActiveSessions(comp) ?: emptyList() }
                       catch (_: SecurityException) { emptyList() }
        val active = sessions.firstOrNull {
            it.playbackState?.state == PlaybackState.STATE_PLAYING
        } ?: sessions.firstOrNull()
        if (active?.sessionToken != controller?.sessionToken) {
            controller?.unregisterCallback(cb)
            controller = active?.also { it.registerCallback(cb) }
            NowPlaying.transport = controller?.transportControls
        }
        push()
    }

    private fun push() {
        val c = controller ?: return
        val m = c.metadata ?: return
        val title = m.getString(MediaMetadata.METADATA_KEY_TITLE) ?: ""
        val artist = m.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: m.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST) ?: ""
        val art: Bitmap? = m.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: m.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: m.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
        val playing = c.playbackState?.state == PlaybackState.STATE_PLAYING
        NowPlaying.update(title, artist, art, playing)
        MusicWidget.refresh(applicationContext)
    }
}
