# Music Wallpaper (Malyk Brown 2026) — fresh build

Live wallpaper + home-screen widget + liquid-glass Compose UI + equalizer.

## Why this build is different
- Includes a committed Gradle wrapper (gradlew + jar) — the missing wrapper was
  the likely cause of earlier silent Actions failures.
- Pinned, version-matched dependencies (Kotlin 2.0.20 + Compose plugin 2.0.20).
- Widget receiver is exported=true so the launcher can place it.

## Build in Codespaces
Drag MusicWallpaper.zip into your repo, then:

```bash
unzip -o "MusicWallpaper.zip"
cp -r MusicWallpaper/. .
rm -rf MusicWallpaper "MusicWallpaper.zip"
chmod +x gradlew
git add -A
git commit -m "Music Wallpaper - fresh build"
git push
```

Then: Actions -> Build APK -> MusicWallpaper-debug.

You can also build directly in Codespaces to see real errors:
```bash
./gradlew assembleDebug --stacktrace
```

## On the phone
1. Install APK
2. App -> activar acesso as notificacoes -> liga "Music Wallpaper"
3. Definir como papel de parede
4. Widget: long-press home screen -> Widgets -> Music Wallpaper -> arrasta

minSdk 33 (Android 13+) — needed for the AGSL glass shader.
